<div class="header">
    <div class="header1"><img src="images/logo1.jpg" width="229" height="36" /></div>
    <div class="header2">
      <div id="container">
        <div id="mainmenu">
          <ul>
            <li><a href="index.php" class="a">Home</a></li>
            <li><a href="Profile.php" class="a">Profile</a></li>
            <li><a href="Buy.php" class="a">Buy</a></li>
            <li><a href="Sale.php" class="a">Sale</a></li>
           	<li><a href="Image.php" class="a">Image</a></li>
            <li><a href="Logout.php" class="a">Logout</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="headerimage">
    <div class="headeriamge1">
      <div class="house"></div>
    </div>
    <div class="">
      
    </div>
    <div>
    
    </div>
  </div>