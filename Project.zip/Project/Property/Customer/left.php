<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style6 {font-family: Verdana, Arial, Helvetica, sans-serif; font-size: small; color: #FFFFFF;}
-->
</style>
<div class="leftpannel">
  <div class="find">
          <div class="leftpan1"></div>
          <div class="leftpan2">
            <div class="leftmenu">
             <marquee direction="up" height="180">
             <span class="style6">Buy ,Sell or Rent Your Property</span>
             </marquee>
            .</div>
          </div>
  </div>
  <div class="search">
    <div class="search1"></div>
    
  </div>
        
      </div>

