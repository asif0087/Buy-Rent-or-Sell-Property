 <div class="footer">
      <div class="text">2013 All Rights Reserved </div>

    </div>